package com.insurance.insuranceCompany.rowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.insurance.insuranceCompany.model.FAQ;

public class FAQRowMapper implements RowMapper<FAQ> {

    @Override
    public FAQ mapRow(ResultSet rs, int rowNum) throws SQLException {
        FAQ faq = new FAQ();
        faq.setId(rs.getLong("id"));
        faq.setQuestion(rs.getString("question"));
        faq.setAnswer(rs.getString("answer"));
        return faq;
    }
}